package com.example.myapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        //This initializes the List view that will display the news articles
        ListView newsListView = findViewById(R.id.newsListView);
        //This gets the list of news so it returns the sample data used in CulturalEventsActivity.java
        List<String> newsArticles = getNewsArticles();

        //This creates an ArrayAdapter to convert the list of news into a format suitable for the ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, newsArticles); //This uses a simple layout for each item

        //This sets the adapter to the ListView, so it knows how to display the news articles
        newsListView.setAdapter(adapter);
    }

    //This is a method to generate the list of news articles
    private List<String> getNewsArticles() {
        //This creates a new list to store the news articles
        List<String> articles = new ArrayList<>();
        // Add sample news articles
        articles.add("New Exhibition Opens at National Museum - 1st Nov 2024");
        articles.add("Cultural Heritage Month Celebrations Announced - 5th Nov 2024");
        articles.add("Welsh Language Initiative Launched - 10th Nov 2024");
        articles.add("New Artifacts Discovered in St. Fagans - 15th Nov 2024");
        //This returns the list of news articles
        return articles;
    }
}
