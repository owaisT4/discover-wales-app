package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class VirtualTourActivitytwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_virtual_tourtwo); //This is the layout for this java class


        //This is the code that allows users to click on the back button to take them back for romanActivity.class.

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), romanActivity.class);
            startActivity(intent);
        });


        // Here I am locating the IDs from the activity_virtual_tour xml file as this will format how my virtual tour will look.
        WebView webView1 = findViewById(R.id.webview_1);
        WebView webView2 = findViewById(R.id.webview_2);
        WebView webView3 = findViewById(R.id.webview_3);

        /*This is where I am locating the URLs from the browser for virtual tours. This is sp when the user clicks on the Virtual tour button it will redirect them to the activity_virtual
        _tour file and display instantly the virtual tour. */
        webviewsetup(webView1, "https://my.matterport.com/show/?m=ihBWMNFMBA3");
        webviewsetup(webView2, "https://my.matterport.com/show/?m=Xgf7RFTHndg");
        webviewsetup(webView3, "https://my.matterport.com/show/?m=FNW7ab3eFdV");
    }

    // This is a helper method to set up Web view
    private void webviewsetup(WebView webView, String url) {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // This enables javascript if needed
        webView.loadUrl(url);
    }
}
