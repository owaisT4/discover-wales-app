package com.example.myapp;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class CultureItemAdapter extends BaseAdapter {

    private Context context; // This is the context of the activity where the adapter is used
    private List<CultureItem> cultureItems; // This is the list of Culture item objects to be displayed
    private List<CultureItem> cultureItemsFull; // This is a copy of the full list for filtering purposes


    //This is a constructor to set up the adapter with the context and list of culture items
    public CultureItemAdapter(Context context, List<CultureItem> cultureItems) {
        this.context = context;
        this.cultureItems = cultureItems;
        this.cultureItemsFull = new ArrayList<>(cultureItems); // This creates a copy of the list for filtering
    }

    @Override
    public int getCount() {
        return cultureItems.size();  // This returns the number of items in the filtered list
    }

    @Override
    public Object getItem(int position) {
        return cultureItems.get(position); // This returns the culture items at the given position
    }

    @Override
    public long getItemId(int position) {
        return position; // This returns the unique ID of the item but in my case its just a position
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // This means if the convertView is null which means a new view is needed, create a new view using the default layout
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        // This finds the text views from the layout to display the title and description
        TextView titleTextView = convertView.findViewById(android.R.id.text1);
        TextView descriptionTextView = convertView.findViewById(android.R.id.text2);

        //This sets the current Culture Item from the list based on the position
        CultureItem currentItem = cultureItems.get(position);
        //This sets the title and description of the item in the text views
        titleTextView.setText(currentItem.getTitle());
        descriptionTextView.setText(currentItem.getDescription());

        // This sets up a click listener to open the URL when the item is clicked
        convertView.setOnClickListener(v -> {

            String url = currentItem.getUrl();  // This means to get the url of the clicked item
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));  // This means to create an intent to open the URL in a browser
            context.startActivity(intent);  // This means to start the activity so open the browser
        });

        return convertView; // This means to return the view that will be displayed in the ListView
    }

    // This is a method to filter the list based on the search query
    public void filter(String query) {
        List<CultureItem> filteredList = new ArrayList<>(); // This is the list to store the filtered results
        if (query.isEmpty()) {
            //if the search query is empty then show the full the items
            filteredList.addAll(cultureItemsFull);
        } else {
            for (CultureItem item : cultureItemsFull) {
                // if the title or description contains the search query but is case-insensitive, add it to the filtered list
                if (item.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                        item.getDescription().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(item);
                }
            }
        }

        // This means to update the list with the filtered items
        cultureItems.clear(); //This means to clear the current list
        cultureItems.addAll(filteredList); //Add the filtered items
        notifyDataSetChanged();  //Alert the adapter that the data has been changed, so the list view can update
    }
}
