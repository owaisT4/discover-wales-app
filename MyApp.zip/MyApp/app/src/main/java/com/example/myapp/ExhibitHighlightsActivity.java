package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ExhibitHighlightsActivity extends AppCompatActivity {
    private ImageView exhibitImage; //This code displays the current exhibit
    private TextView exhibitDescription; // This displays the description for the current exhibit
    private Button prevButton; // This is the button to navigate to the previous exhibit
    private Button nextButton; // This is the button to navigate to the next exhibit

    // This is an array that consists of all the images that will be in the Exhibit highlights page
    private int[] images = {
            R.drawable.exhibit1,
            R.drawable.exhibit2,
            R.drawable.exhibit3,
            R.drawable.exhibit4,
            R.drawable.exhibit5,
            R.drawable.exhibit6,
            R.drawable.exhibit7,
            R.drawable.exhibit8,
            R.drawable.exhibit9,
            R.drawable.stf1,
            R.drawable.stf2,
            R.drawable.stf3,
            R.drawable.st4,

    };

    // This is the array to store exhibit descriptions which is done later
    private String[] descriptions;

    //This is the index that tracks the current exhibit being displayed
    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exhibit_highlights);

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });


        exhibitImage = findViewById(R.id.exhibitImage);
        exhibitDescription = findViewById(R.id.exhibitDescription);
        prevButton = findViewById(R.id.prevButton);
        nextButton = findViewById(R.id.nextButton);

        // This is where I begin initalizing the descriptions array
        descriptions = getDescriptions();

        //This automatically shows the first image of the exhibit
        updateExhibit();

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex > 0) { //This checks if there is an previous exhibit
                    currentIndex--; // This decreases the index
                    updateExhibit(); // This updates the UI
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex < images.length - 1) { //This checks if there is an next exhibit
                    currentIndex++; // This increases the index
                    updateExhibit(); // This updates the UI
                }
            }
        });
    }

    //This piece of code updates the UI to display the current exhibit based on the index
    private void updateExhibit() {
        exhibitImage.setImageResource(images[currentIndex]); // This sets the image for the current index
        exhibitDescription.setText(descriptions[currentIndex]); // This sets the descriptions for the current exhibition
    }

    private String[] getDescriptions() {
        String[] descriptions = new String[11];

        descriptions[0] = getString(R.string.exhibit_1);
        descriptions[1] = getString(R.string.exhibit_2);
        descriptions[2] = getString(R.string.exhibit_3);
        descriptions[3] = getString(R.string.exhibit_4);
        descriptions[4] = getString(R.string.exhibit_5);
        descriptions[5] = getString(R.string.exhibit_6);
        descriptions[6] = getString(R.string.exhibit_7);
        descriptions[7] = getString(R.string.exhibit_8);
        descriptions[8] = getString(R.string.exhibit_9);
        descriptions[9] = getString(R.string.exhibit_10);
        descriptions[10] = getString(R.string.exhibit_11);

        return descriptions;
    }
}
