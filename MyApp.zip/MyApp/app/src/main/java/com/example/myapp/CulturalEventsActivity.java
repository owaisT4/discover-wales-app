package com.example.myapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CulturalEventsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cultural_events);

        //This initializes the List view to display the events
        ListView eventsListView = findViewById(R.id.eventsListView);
        //This gets the list of events
        List<String> events = getEvents();


        //Here we are creating an ArrayAdapter to convert the lit of events into a format that can be displayed in the List view
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, events);

        //Sets the adapter to the listview, so it knows how to display the events
        eventsListView.setAdapter(adapter);
    }

    private List<String> getEvents() {
        List<String> events = new ArrayList<>(); //This creates a new list to store the events
        // If I wanted I can add more sample data here
        events.add(getString(R.string.exhibition_welsh_art));
        events.add(getString(R.string.cultural_festival));
        events.add(getString(R.string.museum_open_day));
        events.add(getString(R.string.traditional_music_night));

        //returns the list of events
        return events;
    }
}
