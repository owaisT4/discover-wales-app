package com.example.myapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class NotificationHelper {

    // This isused to identify the notification channel
    private static final String CHANNEL_ID = "events_channel";

    // This method is used to create the notification channel
    public static void createNotificationChannel(Context context) {
        // This checks if your device is running Android 8.0 or above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Events Notifications"; // This is the name of channel
            String description = "Notifications for events and news"; //This is the description of the channel
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            //This is used to create the Notification channel with the defined name, description and importance level
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description); //This sets the description for the channe;

            // This gets the systems Notification manager to manage the notification channel
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    // This method sends the notification with a title and a message
    public static void sendNotification(Context context, String title, String message) {
        // This builds the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.notification_icon) // Ensure this icon exists in your resources
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // This gets the NotificationManager system service to manage notifications
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(1, builder.build());  //This notifys the system to show the notification with the ID '1'
        }
    }
}
