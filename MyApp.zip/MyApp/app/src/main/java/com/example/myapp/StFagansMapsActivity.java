package com.example.myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.StreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class StFagansMapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap; //This is the variable that I will be using to hold the Google Map object
    private StreetViewPanorama streetViewPanorama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // This is to set up the SupportMapFragment to display the Google Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this); //This is about telling the fragment to prepare the Map
        }

        // This is for preparing StreetViewPanoramaFragment to display the street view
        StreetViewPanoramaFragment streetViewPanoramaFragment = (StreetViewPanoramaFragment)
                getFragmentManager().findFragmentById(R.id.street_view_panorama);

        //This checks if the Street View panorma fragment exists
        if (streetViewPanoramaFragment != null) {
            streetViewPanoramaFragment.getStreetViewPanoramaAsync(panorama -> {
                // Store panorama instance
                streetViewPanorama = panorama;


                //This creates a LatLng object for St fagans
                LatLng stfagans = new LatLng(51.4879, 3.2686);
                panorama.setPosition(stfagans);
            });
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;


        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);


        LatLng stfagans = new LatLng(51.4879, 3.2686
        );


        //This allows users to move and zoom the camera to St fagans
        mMap.addMarker(new MarkerOptions()
                .position(stfagans)
                .title("St Fagans Museum"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(stfagans, 15));
    }
}
