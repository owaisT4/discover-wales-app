package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class EventsAndNewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_and_news);

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });


        ListView eventsListView = findViewById(R.id.eventsListView);
        ListView newsListView = findViewById(R.id.newsListView);

        //This is getting the lists of events and news using helper methods
        List<String> events = getEvents();
        List<String> news = getNews();

        //This is about creating an ArrayAdapter for events and set it to the eventsListView
        ArrayAdapter<String> eventsAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, events); // This is a simple layout for each event
        eventsListView.setAdapter(eventsAdapter); //This is setting the adapter to display the event list

        //This is about creating an ArrayAdapter for news and set it to the eventsListView
        ArrayAdapter<String> newsAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, news); // This is a simple layout for each news
        newsListView.setAdapter(newsAdapter); //This is setting the adapter to display the news list
    }


    //This is the helper method to return a list of events
    private List<String> getEvents() {
        List<String> events = new ArrayList<>();
        // This is about retrieving the events from the string file
        events.add(getString(R.string.exhibition_welsh_art));
        events.add(getString(R.string.cultural_festival));
        events.add(getString(R.string.museum_open_day));
        events.add(getString(R.string.traditional_music_night));
        return events; // return the list of events
    }


    //This is the helper method to return a list of news
    private List<String> getNews() {
        List<String> news = new ArrayList<>();

        // This is about retrieving the news from the string file
        news.add(getString(R.string.news_exhibition_opening));
        news.add(getString(R.string.news_welsh_language_day));
        news.add(getString(R.string.news_changes_to_hours));

        return news; // return the list of news
    }
}
