package com.example.myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.StreetViewPanorama;
import com.google.android.gms.maps.StreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class RomanMuseumMapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private StreetViewPanorama streetViewPanorama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Initialize the Map Fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Initialize the Street View Panorama Fragment
        StreetViewPanoramaFragment streetViewPanoramaFragment = (StreetViewPanoramaFragment)
                getFragmentManager().findFragmentById(R.id.street_view_panorama);

        if (streetViewPanoramaFragment != null) {
            streetViewPanoramaFragment.getStreetViewPanoramaAsync(panorama -> {
                // Store panorama instance
                streetViewPanorama = panorama;

                // Set the Street View location to the Roman Museum coordinates
                LatLng romanMuseum = new LatLng(51.6095390, -2.9540300); // Replace with actual coordinates
                panorama.setPosition(romanMuseum);
            });
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Set map type to normal
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        // Set the location for the Roman Museum
        LatLng romanMuseum = new LatLng(51.6095390, -2.9540300
        ); // Replace with actual coordinates

        // Add marker and move camera to Roman Museum
        mMap.addMarker(new MarkerOptions()
                .position(romanMuseum)
                .title("Roman Museum"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(romanMuseum, 15));
    }
}
