package com.example.myapp;

import android.content.Intent;
import android.net.Uri;  // For handling URIs
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class romanActivity extends AppCompatActivity {

    // Image Slider variables
    private ImageView imageView;
    private int[] images = {R.drawable.exhibit7, R.drawable.exhibit8, R.drawable.exhibit9};  // Add your image resources
    private int currentImageIndex = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.roman); // Reference the roman.xml layout

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), CultureHeritageActivity.class);
            startActivity(intent);
        });


        // Initialize the ImageView for the image slider
        imageView = findViewById(R.id.imageView);  // Make sure this ID matches your ImageView in the layout XML

        // Start the image slider
        startImageSlider();


        // Initialize the Street View button
        Button streetViewButton = findViewById(R.id.roman_museum_map_button);
        streetViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to MapsActivity (for Street View)
                Intent intent = new Intent(romanActivity.this, MapsActivity.class);
                // Pass the latitude and longitude for the Roman Museum (replace with actual location)
                intent.putExtra("latitude", 51.6095390); // Example latitude for Roman Museum
                intent.putExtra("longitude", -2.9540300); // Example longitude for Roman Museum
                startActivity(intent);
            }
        });

        // Initialize the Virtual Tour button
        Button virtualTourButton = findViewById(R.id.virtual_tour_button);
        virtualTourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to VirtualTourActivitytwo
                Intent intent = new Intent(romanActivity.this, VirtualTourActivitytwo.class);
                startActivity(intent); // Open the Virtual Tour Activity
            }
        });

        // Social Media Icons (Facebook and Twitter)
        ImageView Instagram = findViewById(R.id.Instagram_icon);
        Instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to open Facebook link
                Uri InstagramUri = Uri.parse("https://www.instagram.com/explorewales24/");
                Intent InstagramIntent = new Intent(Intent.ACTION_VIEW, InstagramUri);
                startActivity(InstagramIntent);
            }
        });

        ImageView twitterIcon = findViewById(R.id.twitter_icon);
        twitterIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open Twitter page
                Uri twitterUri = Uri.parse("https://x.com/explorewales24");
                Intent twitterIntent = new Intent(Intent.ACTION_VIEW, twitterUri);
                startActivity(twitterIntent);
            }
        });
    }

    private void startImageSlider() {

        Runnable updateImageRunnable = new Runnable() {
            @Override
            public void run() {
                imageView.setImageResource(images[currentImageIndex]);

                // Move to the next image in the array
                currentImageIndex = (currentImageIndex + 1) % images.length;

                // Schedule the next update after 3 seconds (3000 ms)
                handler.postDelayed(this, 3000);
            }
        };

        // Start the image updates
        handler.post(updateImageRunnable);
    }
    }

