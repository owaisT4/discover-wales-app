package com.example.myapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.content.pm.PackageManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    private static final int REQUEST_NOTIFICATION_PERMISSION = 1; // This is used to identify the permission request for notifications.
    private GoogleMap gMap; // This is a variable to store the Google Map object but its actually not used in MainActivity.

    @Override
    protected void onCreate(Bundle savedInstanceState) {   /* onCreate is called when the activity is first created. Its where you usally set up the
                                                            user interface, initialize variables, and start other processors. The savedInstanceState is a bundle
                                                            that stores any data from the previous session like if the app was paused and then resumed. */
        super.onCreate(savedInstanceState);

        //Checks and set the langauge on app start
        checkAndSetLanguage();

        setContentView(R.layout.activity_main);

        //Request Notification on Android 13 and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
            } else {
                //Permission already granted, proceed with notification
                initializeNotifications();
            }
        } else {
            //No need to request permission for older versions
            initializeNotifications();
        }
        initializeButtons();
    }


    //Below is the code to show how you make the buttons navigate to different pages
    private void initializeButtons() {
        Button cultureHeritageButton = findViewById(R.id.CultureHeritageButton);
        cultureHeritageButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CultureHeritageActivity.class);
            startActivity(intent);
        });

        Button exhibitHighlightsButton = findViewById(R.id.ExhibitHighlightsButton);
        exhibitHighlightsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ExhibitHighlightsActivity.class);
            startActivity(intent);
        });


        Button eventNewsButton = findViewById(R.id.eventNewsButton);
        eventNewsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EventsAndNewsActivity.class);
            startActivity(intent);
        });

        Button contentLibraryButton = findViewById(R.id.contentLibraryButton);
        contentLibraryButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ContentLibraryActivity.class);
            startActivity(intent);
        });
    }

    //Remember earlier in the code you made a permission request for Notifications? The code below shows the result to the request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeNotifications();
            } else {
                //Permission denied show message
                Toast.makeText(this, "Notification permission is required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Send a test notification
    private void initializeNotifications() {
        NotificationHelper.createNotificationChannel(this);
        NotificationHelper.sendNotification(this, "Welcome!", "Check out the latest events and News!");
    }

    //Below Code shows how langauge is implemented

    //This is the method to check and apply saved langauge preference
    private void checkAndSetLanguage() {
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        boolean isEnglish = sharedPreferences.getBoolean("language_english", true); // Default to English

        if (!isEnglish) {
            setLocale("cy"); // Set to Welsh if preference is not English
        } else {
            setLocale("en"); // Set to English
        }
    }

    // Method to change the app's language dynamically
    private void setLocale(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale); // Set the default locale

        // Use createConfigurationContext for better compatibility in newer Android versions
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().createConfigurationContext(config); // Update context with new configuration
    }
}

