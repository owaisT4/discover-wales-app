package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ContentLibraryActivity extends AppCompatActivity {

    private ListView listView; // This displays the list of cultural items
    private List<CultureItem> cultureItems; // This holds the data for the culture items
    private CultureItemAdapter adapter; // This is a custom adapter for putting together culture items to the List view

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_library);

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });


        // This code is about setting up the search view and list view
        listView = findViewById(R.id.cultureListView);
        SearchView searchView = findViewById(R.id.searchView);

        // This initializes the list of culture items
        cultureItems = new ArrayList<>();
        loadCultureItems();

        // This creates an adapter to put together culture items to the list view
        adapter = new CultureItemAdapter(this, cultureItems);
        listView.setAdapter(adapter); // This sets the adapter to the list view

        // This sets up search view to listen to user input and filter items based on the user input
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // Ignore query submit
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // This filters the list based on the users search query
                adapter.filter(newText);
                return false;
            }
        });
    }

    private void loadCultureItems() {
        // Add culture items and their corresponding URLs
        cultureItems.add(new CultureItem(getString(R.string.welsh_language), getString(R.string.welsh_language_description), "https://www.historic-uk.com/HistoryUK/HistoryofWales/Welsh-Language/"));
        cultureItems.add(new CultureItem(getString(R.string.traditional_music), getString(R.string.traditional_music_description), "https://www.walesonline.co.uk/whats-on/whats-on-news/50-greatest-welsh-songs-time-7222907"));
        cultureItems.add(new CultureItem(getString(R.string.history_of_wales), getString(R.string.history_of_wales_description), "https://www.britannica.com/place/Wales"));
}}
