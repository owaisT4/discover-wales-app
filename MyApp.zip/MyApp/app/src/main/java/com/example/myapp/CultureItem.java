package com.example.myapp;

public class CultureItem {
    private String title; // This is the title of the culture items
    private String description; // Thi is the description of the culture items
    private String url; // This is the URL to more information about culture items


    //This is a constructer to set up the culture items with title, descriptions and URL
    public CultureItem(String title, String description, String url) {
        this.title = title;
        this.description = description;
        this.url = url;
    }

    // This is a method to retrieve the title of the culture items
    public String getTitle() {
        return title;
    }

    // This is a method to retrieve the description of the culture items
    public String getDescription() {
        return description;
    }

    // This is a method to retrieve the URL of the culture items
    public String getUrl() {
        return url;
    }

    // the toString() method formats how the culture items will be displayed
    @Override
    public String toString() {
        return title + "\n" + description;  // This will be used to show both title and description in a List View
    }
}
