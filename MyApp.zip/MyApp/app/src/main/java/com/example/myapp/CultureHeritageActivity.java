package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class CultureHeritageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cultureheritage);

        //This is how you add navigation to the buttons

        Button backbutton = findViewById(R.id.back);
        backbutton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });

        //Here we are finding the nationalmuseumbutton from the xml file cultureheritage
        Button NationalMuseumButton = findViewById(R.id.National_museum_button);
        //Now we are setting a onclick listener to take a user from this activity to the NationalMusuem activty.
        NationalMuseumButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CultureHeritageActivity.this, NationalMuseum.class);
                startActivity(intent);
            }
        });


        Button StFagansButton = findViewById(R.id.button_stfagans);
        StFagansButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CultureHeritageActivity.this, StFagansActivity.class);
                startActivity(intent); // Start St Fagans activity
            }
        });


        Button RomanButton = findViewById(R.id.roman_button);
        RomanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CultureHeritageActivity.this, romanActivity.class);
                startActivity(intent);
            }
        });


    }
}
