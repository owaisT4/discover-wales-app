package com.example.myapp;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.StreetViewPanoramaFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap; //This is the variable that I will be using to hold the Google Map object

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps); //This will be the layout of the screen

        // Get the latitude and longitude from the intent
        double latitude = getIntent().getDoubleExtra("latitude", 0); // This is 0 because in case something goes wrong. This is something to fall back to.
        double longitude = getIntent().getDoubleExtra("longitude", 0); // This is 0 because in case something goes wrong. This is something to fall back to.

        // This is to set up the SupportMapFragment to display the Google Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map); // This is for finding the ID from the xml file
        if (mapFragment != null) {
            mapFragment.getMapAsync(this); //This is about telling the fragment to prepare the Map
        }

        // This is for preparing StreetViewPanoramaFragment to display the street view
        StreetViewPanoramaFragment streetViewPanoramaFragment = (StreetViewPanoramaFragment)
                getFragmentManager().findFragmentById(R.id.street_view_panorama); // This is for finding the ID from the xml file

        //Below is the code to say if the latitude and longitude have passed then set the location for street view.

        if (streetViewPanoramaFragment != null) {
            streetViewPanoramaFragment.getStreetViewPanoramaAsync(panorama -> {
                // Set the Street View location to the passed coordinates
                LatLng location = new LatLng(latitude, longitude);
                panorama.setPosition(location); //Update the street view to show this location
            });
        }
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap; // As mentioned before I will be using the mMap variable. This is the variable in which i will store the map object

        // Here I am setting the map to normal
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);


        double latitude = getIntent().getDoubleExtra("latitude", 0); // This is all fallback values if the location cannot be found for some reason
        double longitude = getIntent().getDoubleExtra("longitude", 0); // This is all fallback values if the location cannot be found for some reason

        // Here I am creating a LatLng object for the location using Latitude and Longitude.
        LatLng location = new LatLng(latitude, longitude);

        // Below is the code to show the red marker at the specified Location.
        mMap.addMarker(new MarkerOptions()
                .position(location)
                .title("St Fagans Museum"));
        //Here I am zooming into the map level 15.
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15));
    }
}
