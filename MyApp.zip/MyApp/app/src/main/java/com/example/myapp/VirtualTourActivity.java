package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class VirtualTourActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_virtual_tour); //This is the layout for this java class

        //This is the code that allows users to click on the back button to take them back for NationalMuseum.class.
        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), NationalMuseum.class);
            startActivity(intent);
        });


        // Here I am locating the IDs from the activity_virtual_tour xml file as this will format how my virtual tour will look.
        WebView webView1 = findViewById(R.id.webview_1);
        WebView webView2 = findViewById(R.id.webview_2);
        WebView webView3 = findViewById(R.id.webview_3);
        WebView webView4 = findViewById(R.id.webview_4);

        // Here I am enabling javascript settings etc for web view
        enableWebViewSettings(webView1);
        enableWebViewSettings(webView2);
        enableWebViewSettings(webView3);
        enableWebViewSettings(webView4);




        /*This is where I am locating the URLs from the browser for virtual tours. This is sp when the user clicks on the Virtual tour button it will redirect them to the activity_virtual
        _tour file and display instantly the virtual tour. */
        webView1.loadUrl("https://my.matterport.com/show/?m=VLWSNX62ax8");
        webView2.loadUrl("https://my.matterport.com/show/?m=9D1eaaBaiNB");
        webView3.loadUrl("https://my.matterport.com/show/?m=s87VCae824d");
        webView4.loadUrl("https://my.matterport.com/show/?m=i812RUXgJh7");
    }

    //This is additional settings to help users have a good experience with virtual tour.
    private void enableWebViewSettings(WebView webView) {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Enable JavaScript
        webSettings.setAllowFileAccess(true);    //Allow File Access
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setDomStorageEnabled(true);
    }

    // This is for in case the page fails to load.
    private class WebViewClientWithErrorHandling extends WebViewClient {
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            view.loadData("<html><body><h2>Sorry, the page could not be loaded.</h2></body></html>", "text/html", "UTF-8");
        }
    }
}
