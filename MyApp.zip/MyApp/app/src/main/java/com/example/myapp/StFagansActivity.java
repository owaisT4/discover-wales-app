package com.example.myapp;

import android.net.Uri;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class StFagansActivity extends AppCompatActivity {


    private ImageView imageView; //This will be used to display the images in the image slider.
    private int[] images = {R.drawable.stf1, R.drawable.stf2, R.drawable.stf3, R.drawable.st4};  // This is where I have added in my images
    private int currentImageIndex = 0; //This keeps track of the current image being displayed in the slider.
    private Handler handler = new Handler(); // This is used to schedule and manage the image switching every 3 seconds.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stfagans); //The layout of this activity will be my stfagans xml file


        //Below is me adding the functionality to allow users to click the back button to take them to the previous activity
        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), CultureHeritageActivity.class);
            startActivity(intent);
        });


        // This is setting up the ImageView for image slider
        imageView = findViewById(R.id.imageView);

        // Begin Image Slider to show the images
        startImageSlider();

        //This is the code to allow users to click on the street view button which will redirect them to build in google maps api to National Museum.
        Button streetViewButton = findViewById(R.id.street_view_button);
        streetViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Launch MapsActivity and pass St. Fagans coordinates
                Intent intent = new Intent(StFagansActivity.this, MapsActivity.class);
                intent.putExtra("latitude", 51.4879); // These are the Coordinates for St Fagans
                intent.putExtra("longitude", -3.2686); // These are the Coordinates for St Fagans
                startActivity(intent);
            }
        });


        ImageView Instagram = findViewById(R.id.Instagram_icon);
        Instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri InstagramUri = Uri.parse("https://www.instagram.com/explorewales24/");
                Intent InstagramIntent = new Intent(Intent.ACTION_VIEW, InstagramUri);
                startActivity(InstagramIntent);
            }
        });

        ImageView twitterIcon = findViewById(R.id.twitter_icon);
        twitterIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri twitterUri = Uri.parse("https://x.com/explorewales24");
                Intent twitterIntent = new Intent(Intent.ACTION_VIEW, twitterUri);
                startActivity(twitterIntent);
            }
        });
    }

    private void startImageSlider() {
//The runnable is added to delay the image switching every 3 seconds to create the image slider effect.
        Runnable updateImageRunnable = new Runnable() {
            @Override
            public void run() {
                //The image is updated by changing the Image View resource (imageView.setImageResource())
                imageView.setImageResource(images[currentImageIndex]);

                // Move to the next image
                currentImageIndex = (currentImageIndex + 1) % images.length;

                // After 3 seconds update the image
                handler.postDelayed(this, 3000);
            }
        };

        // This snippet is for updating the images
        handler.post(updateImageRunnable);
    }
    }

