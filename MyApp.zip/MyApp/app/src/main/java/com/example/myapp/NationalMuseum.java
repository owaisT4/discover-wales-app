package com.example.myapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class NationalMuseum extends AppCompatActivity {



    // These are the different variables I will be using to make the Image sider work
    private ImageView imageView; //This will be used to display the images in the image slider.
    private int[] images = {R.drawable.exhibit1, R.drawable.exhibit2, R.drawable.exhibit3, R.drawable.exhibit4, R.drawable.exhibit5, R.drawable.exhibit6};  // This is where I have added in my images
    private int currentImageIndex = 0; //This keeps track of the current image being displayed in the slider.
    private Handler handler = new Handler(); // This is used to schedule and manage the image switching every 3 seconds.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nationalmeuseum);  //The layout of this activity will be my nationalmeuseum xml file

        //Below is me adding the functionality to allow users to click the back button to take them to the previous activity

        Button back = findViewById(R.id.back);
        back.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), CultureHeritageActivity.class);
            startActivity(intent);
        });

        // This is setting up the ImageView for image slider
        imageView = findViewById(R.id.imageView);  // I need to make sure the ID matches what its in my xml file

        // Begin Image Slider to show the images
        startImageSlider();

        //This is the code to allow users to click on the street view button which will redirect them to build in google maps api to National Museum.

        Button streetViewButton = findViewById(R.id.street_view_button);
        streetViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NationalMuseum.this, MapsActivity.class);
                intent.putExtra("latitude", 51.4850); // These are the Coordinates for National Museum
                intent.putExtra("longitude", -3.1802); // These are the Coordinates for National Museum
                startActivity(intent);
            }
        });


        Button virtualTourButton = findViewById(R.id.virtual_tour_button);
        virtualTourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to VirtualTourActivity
                Intent intent = new Intent(NationalMuseum.this, VirtualTourActivity.class);
                startActivity(intent);
            }
        });


        ImageView instagramIcon = findViewById(R.id.Instagram_icon);
        instagramIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the instagrm link
                Uri instagramUri = Uri.parse("https://www.instagram.com/explorewales24/");
                Intent instagramIntent = new Intent(Intent.ACTION_VIEW, instagramUri);
                startActivity(instagramIntent);
            }
        });


        ImageView twitterIcon = findViewById(R.id.twitter_icon);
        twitterIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSocialMedia("https://x.com/explorewales24");
            }
        });
    }

    private void startImageSlider() {
//The runnable is added to delay the image switching every 3 seconds to create the image slider effect.
        Runnable updateImageRunnable = new Runnable() {
            @Override
            public void run() {
                //The image is updated by changing the Image View resource (imageView.setImageResource())
                imageView.setImageResource(images[currentImageIndex]);

                // Move to the next image
                currentImageIndex = (currentImageIndex + 1) % images.length;

                // After 3 seconds update the image
                handler.postDelayed(this, 3000);
            }
        };

        // This snippet is for updating the images
        handler.post(updateImageRunnable);
    }

    //This piece of code opens the provided social media URLs in the users browsers
    private void openSocialMedia(String url) {
        Uri socialMediaUri = Uri.parse(url);
        Intent socialMediaIntent = new Intent(Intent.ACTION_VIEW, socialMediaUri);
        startActivity(socialMediaIntent);
    }
}
